var dbConn = require("../../config/db.config");
var crypto = require("crypto");
var async = require("async");
const bcrypt = require("bcrypt");

const EmployeeModel = {
  deleteDepartmentModel: deleteDepartmentModel,
  getDepartmentModel: getDepartmentModel,
  createDepartmentModel: createDepartmentModel,
  assignDepartmentModel: assignDepartmentModel,
  deleteEmployeeModel: deleteEmployeeModel,
  getEmployeeModel: getEmployeeModel,
  createUserModel: createUserModel,
  autherizationModel: autherizationModel
}

function assignDepartmentModel(userReqData, callBack) {
  var getData =
    "CALL spAssignDepartment('" + userReqData.Id + "', '" + userReqData.Department + "')";
  dbConn.query(getData, (err, results, fields) => {
    if (err) {
      console.log("Error while inserting data");
      callBack(err);
    } else {
      console.log("User Profile created successfully");
      return callBack(null, results);
    }
  });
};

function deleteDepartmentModel(userReqData, callBack) {
  var getData =
    "CALL spRemoveDepartmentData('" + userReqData.Id + "')";
  dbConn.query(getData, (err, results, fields) => {
    if (err) {
      console.log("Error while inserting data");
      callBack(err);
    } else {
      console.log("User Profile created successfully");
      return callBack(null, results);
    }
  });
};

function getDepartmentModel(userReqData, callBack) {
  var getData =
    "CALL spGetDepartmentData()";
  dbConn.query(getData, (err, results, fields) => {
    if (err) {
      console.log("Error while inserting data");
      callBack(err);
    } else {
      console.log("User Profile created successfully");
      return callBack(null, results);
    }
  });
};

function createDepartmentModel(userReqData, callBack) {
  var createDepartment =
    "CALL spAddUpdateDepartment('" + userReqData.Id + "','" + userReqData.DepartmentName + "','" + userReqData.CurrentUser + "')";
  dbConn.query(createDepartment, (err, results, fields) => {
    if (err) {
      console.log("Error while inserting data");
      callBack(err);
    } else {
      console.log("User Profile created successfully");
      return callBack(null, results);
    }
  });
};

function deleteEmployeeModel(userReqData, callBack) {
  var getData =
    "CALL spRemoveEmployeeData('" + userReqData.Id + "')";
  dbConn.query(getData, (err, results, fields) => {
    if (err) {
      console.log("Error while inserting data");
      callBack(err);
    } else {
      console.log("User Profile created successfully");
      return callBack(null, results);
    }
  });
};

function getEmployeeModel(userReqData, callBack) {
  var getData =
    "CALL spGetEmployeeData('" + userReqData.FilterData + "', '" + userReqData.EmployeeId + "')";
  dbConn.query(getData, (err, results, fields) => {
    if (err) {
      console.log("Error while inserting data");
      callBack(err);
    } else {
      console.log("User Profile created successfully");
      return callBack(null, results);
    }
  });
};

function createUserModel(userReqData, callBack) {
  var signIn =
    "CALL spAddUpdateProfile('" + userReqData.Id + "','" + userReqData.FullName + "','" + userReqData.Password + "','" + userReqData.Email + "','" + userReqData.Phone + "','" + userReqData.Address + "','" + userReqData.Designation + "','','Active')";
  dbConn.query(signIn, (err, results, fields) => {
    if (err) {
      console.log("Error while inserting data");
      callBack(err);
    } else {
      console.log("User Profile created successfully");
      return callBack(null, results);
    }
  });
};

function autherizationModel(LoginId, callBack) {
  var loginUser = `CALL spLogin(?) `;
  dbConn.query(loginUser, [LoginId], (error, results, fields) => {
    if (error) {
      callBack(error);
    } else {
      callBack(null, results[0]);
    }
  });
};

module.exports = EmployeeModel;