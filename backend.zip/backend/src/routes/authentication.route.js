const AuthenticationService = require("../services/authentication.service")

module.exports = (router) => {
  router.post("/deleteDepartment", AuthenticationService.deleteDepartmentService);
  router.get("/getdepartmentdata", AuthenticationService.getDepartmentService);
  router.post("/addupdatedepartment", AuthenticationService.createDepartmentService);

  router.post("/assignDepartment", AuthenticationService.assignDepartmentService);
  router.post("/deleteEmployee", AuthenticationService.deleteEmployeeService);
  router.post("/getEmployeeData", AuthenticationService.getEmployeeService);
  router.post("/authentication", AuthenticationService.createUserService);
  router.post("/login", AuthenticationService.authUserService);
}