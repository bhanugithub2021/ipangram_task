const authenticationModel = require("../models/authentication");
const { hashSync, genSaltSync, compareSync } = require("bcrypt");
const jwt = require("jsonwebtoken");
const { sign } = require("jsonwebtoken");
const bcrypt = require("bcryptjs");

const AuthService = {
  deleteDepartmentService: deleteDepartmentService,
  getDepartmentService: getDepartmentService,
  createDepartmentService: createDepartmentService,
  assignDepartmentService: assignDepartmentService,
  deleteEmployeeService: deleteEmployeeService,
  getEmployeeService: getEmployeeService,
  createUserService: createUserService,
  authUserService: authUserService
}

function assignDepartmentService(req, res) {
  const body = req.body;
  authenticationModel.assignDepartmentModel(body, (err, user) => {
    if (err) {
      res.send(err);
    } else {
      res.json({
        status: true,
        message: "Department Assigned Successfully.",
        data: user,
      });
    }
  });
};

function deleteDepartmentService(req, res) {
  const body = req.body;
  authenticationModel.deleteDepartmentModel(body, (err, user) => {
    if (err) {
      res.send(err);
    } else {
      res.json({
        status: true,
        message: "Data Removed Successfully.",
        data: user,
      });
    }
  });
};

function getDepartmentService(req, res) {
  const body = req.body;
  authenticationModel.getDepartmentModel(body, (err, user) => {
    if (err) {
      res.send(err);
    } else {
      res.json({
        status: true,
        message: "Data get Successfully",
        data: user,
      });
    }
  });
};

function createDepartmentService(req, res) {
  const body = req.body;
  authenticationModel.createDepartmentModel(body, (err, user) => {
    if (err) {
      res.send(err);
    } else {
      res.json({
        status: true,
        message: "Department Created Successfully",
        data: user,
      });
    }
  });

};

function deleteEmployeeService(req, res) {
  const body = req.body;
  authenticationModel.deleteEmployeeModel(body, (err, user) => {
    if (err) {
      res.send(err);
    } else {
      res.json({
        status: true,
        message: "Data Removed Successfully.",
        data: user,
      });
    }
  });
};

function getEmployeeService(req, res) {
  const body = req.body;
  authenticationModel.getEmployeeModel(body, (err, user) => {
    if (err) {
      res.send(err);
    } else {
      res.json({
        status: true,
        message: "Data get Successfully",
        data: user,
      });
    }
  });
};



function createUserService(req, res) {
  const body = req.body;
  const salt = genSaltSync(10);
  body.Password = hashSync(body.Password, salt);
  if (body.constructor === Object && Object.keys(body).length === 0) {
    res.send(400).send({ success: false, message: "Please fill all fields" });
  } else {
    authenticationModel.createUserModel(body, (err, user) => {
      if (err) {
        res.send(err);
      } else {
        res.json({
          status: true,
          message: "User Created Successfully",
          data: user,
        });
      }
    });
  }
};


function authUserService(req, res) {
  const body = req.body;
  authenticationModel.autherizationModel(body.Email, (err, results) => {
    if (err) {
      return res.json({
        status: false,
        message: "Please Enter Valid Email or Password.",
      });
    } else if (results.length == "" || results.length == 0) {
      return res.json({
        status: false,
        message: "Please Enter Valid Email or Password.",
      });
    }

    if (
      results[0].LoginId == "Admin" ||
      results[0].LoginId == "admin" ||
      results[0].LoginId == "ADMIN"
    ) {
      const jsontoken = sign({ result: results }, "this is my secret key", {
        expiresIn: "24day",
      });
      return res.status(200).json({
        status: true,
        data: results,
        message: "login successfully",
        token: jsontoken,
      });
    } else if (results && results.length > 0) {
      const result = compareSync(body.Password, results[0].Password);
      if (result) {
        delete results[0].Password;
        const jsontoken = sign({ result: results }, "this is my secret key", {
          expiresIn: "24day",
        });
        return res.status(200).json({
          status: true,
          data: results,
          message: "login successfully",
          token: jsontoken,
        });
      } else {
        return res.json({
          status: false,
          message: "Please Enter Valid Email or Password.",
        });
      }
    } else {
      return res.json({
        status: false,
        message: "Invalid Credential",
      });
    }
  });
}

module.exports = AuthService;