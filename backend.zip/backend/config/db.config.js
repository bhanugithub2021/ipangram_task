const mysql = require("mysql");

let dbConn = null;
dbConn = mysql.createPool({
  host: "localhost",
  user: "root",
  password: "",
  database: "assignment"
});


dbConn.getConnection(function (error) {
  if (error) {
    console.log(error, "ERROR");
    throw error;
  }
  console.log("Database Connected Successfully!!!");
});

module.exports = dbConn;
