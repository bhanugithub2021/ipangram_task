import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { useNavigate, useLocation, Navigate } from "react-router-dom";
import cogoToast from "cogo-toast";
import axios from "axios";

export default function Signup() {
  const navigation = useNavigate();
  let userDtata = useLocation();
  const [userDetails, setuserDetails] = useState(userDtata.state?.data || {});
  const [designation, setDesignation] = useState(null)


  const {
    register,
    handleSubmit,
    setValue,
    formState: { errors },
    watch,
  } = useForm();
  useEffect(() => {
    setValue("FullName", userDetails?.FullName || "");
    setValue("Designation", userDetails?.Designation || "");
    setValue("Phone", userDetails?.Phone || "");
    setValue("Email", userDetails?.Email || "");
    setValue("password", userDetails?.password || "");
    setValue("ConfirmPassword", userDetails?.ConfirmPassword || "");
  }, [userDetails, setValue]);

  const onSubmit = (data) => {
    const inputData = {
      ...data,
      Id: ""
    }

    const url = "http://localhost:9696/api/authentication";

    axios
      .post(url, inputData)
      .then((res) => {
        if (res.data.status == true) {
          cogoToast.success("Signup Successfully.");
          navigation("/login");
        }
      })
      .catch((error) => {
        console.error("Error submitting form:", error);
      });
  };

  return (
    <div className="maincontainer_head">
      <form onSubmit={handleSubmit(onSubmit)}>
        <div className="mb-3">
          <div style={{ color: "red" }}></div>
          <h3>Signup form</h3>
        </div>

        <div className="mb-3">
          <label>FullName</label>
          <div className="form-text"></div>
          <input
            type="text"
            {...register("FullName", { required: "Please enter Full Name" })}
          />
          {errors.FullName && (
            <p className="error-msg">Please enter Full Name</p>
          )}
        </div>

        <div className="mb-3">
          <label>Designation</label>
          <div className="form-text"></div>

          <select className="select_dr"
            {...register("Designation", { required: "Please select Designation" })}
            onChange={(e) =>
              setDesignation(e.target.value)}
          >

            <option value="Employee">Employee</option>
            <option value="Manager">Manager</option>
          </select>

          {errors.Designation && (
            <p className="error-msg">Please Enter Designation</p>
          )}
        </div>

        <div className="mb-3">
          <label>Phone</label>
          <div className="form-text"></div>
          <input
            type="number"
            {...register("Phone", { required: "Please enter Phone" })}
          />
          {errors.Phone && <p className="error-msg">Please Enter Phone</p>}
        </div>

        <div className="mb-3">
          <label>Address</label>
          <div className="form-text"></div>
          <input
            type="text"
            {...register("Address", { required: "Please enter Address" })}
          />
          {errors.Address && <p className="error-msg">Please Enter Address</p>}
        </div>

        <div className="mb-3">
          <label>Email</label>
          <div className="form-text"></div>
          <input
            type="text"
            {...register("Email", { required: "Please Enter Email" })}
          />
          {errors.Email && (
            <p className="error-msg">Please Enter Email</p>
          )}
        </div>

        <div className="mb-3">
          <label>Password</label>
          <div className="form-text"></div>
          <input
            type="password"
            {...register("Password", { required: "Please Enter Password" })}
          />
          {errors.Password && (
            <p className="error-msg">Please Enter Password</p>
          )}
        </div>

        <div className="mb-3">
          <label>Confirm Password</label>
          <div className="form-text"></div>
          <input
            type="password"
            {...register("ConfirmPassword", {
              required: "Please enter Confirm Password",
              validate: (val) =>
                val === watch("Password") || "Your passwords do not match",
            })}
          />
          {errors.ConfirmPassword && (
            <p className="error-msg">{errors.ConfirmPassword.message}</p>
          )}
        </div>

        <button type="submit" className="btn btn-primary">
          Register
        </button>
        <button
          type="cancel"
          className="btn btn-primary"
          onClick={() => {
            navigation("/login");
          }}
        >
          Cancel
        </button>
      </form>
    </div>
  );
}
