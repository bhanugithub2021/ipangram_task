import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { useNavigate, useLocation, Navigate } from "react-router-dom";
import axios from "axios";
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import sidebar_logo from "../assets/sidebar_logo.webp"
import cogoToast from "cogo-toast";

export default function Login() {
  const navigation = useNavigate();

  const {
    register,
    handleSubmit,
    // setValue,
    formState: { errors },
  } = useForm();


  const onSubmit = (data) => {
    console.log("checkdata", data);

    const url = "http://localhost:9696/api/login";

    axios
      .post(url, data)
      .then((res) => {

        if (res.data.status == true) {
          localStorage.setItem("designation", res.data.data[0].Designation);
          localStorage.setItem("employeename", res.data.data[0].FullName);
          localStorage.setItem("currentuser", res.data.data[0].EmployeeId);
          cogoToast.success("Login Successfully.");
          navigation("/dashbord")
          window.location.reload();
        }

        if (res.data.status == false) {
          cogoToast.error(res.data.message);
        }
      })
      .catch((error) => {
        console.log("Error submitting form:", error);
      });
  };

  return (
    <div className="maincontainer_head">
      <form onSubmit={handleSubmit(onSubmit)}>

        <div className="mb-3">
          <div style={{ color: "red" }}></div>
          <h3>Login form</h3>
        </div>
        <div className="mb-3">
          <img style={{ width: "100%" }} src={sidebar_logo} />
        </div>

        <div className="mb-3">
          <label>Email</label>
          <div className="form-text"></div>
          <input
            type="text"
            {...register("Email", { required: "Please Enter User Name" })}
          />
          {errors.Email && (
            <p className="error-msg">Please Enter Email</p>
          )}
        </div>
        <div className="mb-3">
          <label>Password </label>
          <div className="form-text"></div>
          <input
            type="password"
            {...register("Password", { required: "Please Enter Password" })}
          />
          {errors.Password && (
            <p className="error-msg">Please Enter Password</p>
          )}
        </div>

        <button type="submit" className="btn btn-primary">
          Login
        </button>

        <button
          type="cancel"
          className="btn btn-primary"
          onClick={() => {
            navigation("/signup");
          }}
        >
          Signup
        </button>
      </form>
    </div>
  );
}
