import React, { useState } from 'react';
import { MdDashboard } from "react-icons/md";
import { FaUsers, } from "react-icons/fa6";
import { GiOrganigram } from "react-icons/gi";
import { NavLink } from 'react-router-dom';
import "../Components/Sidebar.css"
import logo from "../assets/logo.svg"
import sidebar_logo from "../assets/sidebar_logo.webp"


const Sidebar = ({ children }) => {
    const [isOpen, setIsOpen] = useState(true);
    const toggle = () => setIsOpen(!isOpen);
    const menuItem = [

        {
            path: "/dashbord",
            name: "Dashboard",
            icon: <MdDashboard />

        },

        {
            path: "/departmentlist",
            name: "Departments",
            icon: <GiOrganigram />

        },

        {
            path: "/userlist",
            name: "Employees",
            icon: <FaUsers />

        },

        // {
        //     path: "/signup",
        //     name: "Signup",
        //     icon: <FaTh />

        // },




    ]
    return (
        <div className="container">
            <div style={{ width: isOpen ? "200px" : "50px" }} className="sidebar">
                <div className="top_section">
                    <img style={{ width: "80%" }} src={sidebar_logo} />
                    {/* <h1 style={{display: isOpen ? "block" : "none"}} className="logo">Logo</h1> */}
                    <div style={{ marginLeft: isOpen ? "50px" : "0px" }} className="bars">
                        {/* <FaBars onClick={toggle}/> */}
                    </div>
                </div>
                {
                    menuItem.map((item, index) => (
                        <NavLink to={item.path} key={index} className="link" activeclassName="active">
                            <div className="icon">{item.icon}</div>
                            <div style={{ display: isOpen ? "block" : "none" }} className="link_text">{item.name}</div>
                        </NavLink>
                    ))
                }
            </div>
            <main>{children}</main>
        </div>
    );
};

export default Sidebar;