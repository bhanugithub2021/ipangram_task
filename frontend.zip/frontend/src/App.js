import React from "react";
import "./App.css";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import Sidebar from "../src/Components/Sidebar";
import User from "../src/Pages/User";
import Userlist from "./Pages/Userlist";
import Dashboard from "./Pages/Dashboard";
import Login from "./Auth/Login";
import Signup from "./Auth/Signup";
import Departmentlist from "./Pages/Departmentlist";
import AddDepartment from "./Pages/AddDepartment";

function App() {
  let logedin = localStorage.getItem("designation");
  console.log("appjsaaa", logedin)
  return (
    <BrowserRouter>
      {logedin === null ? (
        <Routes>
          <Route path="/" element={<Login />} />
          <Route path="/login" element={<Login />} />
          <Route path="/signup" element={<Signup />} />
        </Routes>
      ) : (
        <Sidebar>
          <Routes>
            <Route path="/dashbord" element={<Dashboard />} />
            <Route path="/user" element={<User />} />
            {/* <Route path="/login" element={<Login />} />
          <Route path="/signup" element={<Signup />} /> */}
            <Route path="/userlist" element={<Userlist />} />
            <Route path="/departmentlist" element={<Departmentlist />} />
            <Route path="/adddepartment" element={<AddDepartment />} />
            <Route path="/user/edit" element={<User />} />
          </Routes>
        </Sidebar>
      )}
    </BrowserRouter>
  );
}

export default App;
