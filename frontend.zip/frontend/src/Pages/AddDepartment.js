import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { useNavigate, useLocation } from "react-router-dom";
import axios from "axios";
import cogoToast from "cogo-toast";

export default function Department() {
    const navigation = useNavigate();
    let userDtata = useLocation();
    const [userDetails, setuserDetails] = useState(userDtata.state?.data || {});



    const { register, handleSubmit, setValue, formState: { errors }, } = useForm();
    useEffect(() => {
        setValue("DepartmentName", userDetails?.DepartmentName || "");

    }, [userDetails, setValue]);

    let Currentuser = localStorage.getItem("currentuser");

    const onSubmit = (data) => {
        if (userDtata.state) {
            var inputData = {
                ...data,
                CurrentUser: Currentuser,
                Id: userDtata.state ? userDetails.DepartmentId : ""

            }
        } else {
            var inputData = {
                ...data,
                CurrentUser: Currentuser,
                Id: ""
            }
        }

        const url = "http://localhost:9696/api/addupdatedepartment";

        axios
            .post(url, inputData)
            .then((res) => {
                if (res.data.status == true) {
                    cogoToast.success(userDtata.state ? "Department Updated Successfully." : "Department Created Successfully.");
                    navigation("/departmentlist");
                }
            })
            .catch((error) => {
                console.error("Error submitting form:", error);
            });
    };

    return (
        <div className="maincontainer_login">
            <form onSubmit={handleSubmit(onSubmit)}>
                <div className="mb-3">
                    <div style={{ color: "red" }}></div>
                    <h3>{userDtata.state ? "Edit Department" : "Add Department"}</h3>
                </div>

                <div className="mb-3">
                    <label>Department Name</label>
                    <div className="form-text"></div>
                    <input
                        type="text"
                        {...register("DepartmentName", { required: true })}
                    />
                    {errors.DepartmentName && <p className="error-msg">Please Enter Department Name</p>}
                </div>

                <button type="submit" className="btn btn-primary">
                    Submit
                </button>
                <button
                    type="cancel"
                    className="btn btn-primary"
                    onClick={() => {
                        navigation("/departmentlist");
                    }}
                >
                    Cancel
                </button>
            </form>
        </div>
    );
}
