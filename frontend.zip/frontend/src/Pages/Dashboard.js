import React, { useState } from "react";
import { useHistory } from "react-router-dom";
import { useNavigate, useLocation, Navigate } from "react-router-dom";

function Dashboard() {
  const navigation = useNavigate();
  let Designation = localStorage.getItem("designation");
  let Fullname = localStorage.getItem("employeename");
  let Currentuser = localStorage.getItem("currentuser");




  return (
    <div className="action-btn">
      <h1>Dashboard</h1>
      <h5> Hi {Fullname} ({Designation}) Welcome to the dashboard!</h5>
      <button className="btn btn-primary"
        onClick={() => {
          localStorage.removeItem("designation")
          localStorage.removeItem("employeename")
          localStorage.removeItem("currentuser")
          navigation("/");
          window.location.reload();
        }}
      >Logout</button>

    </div>
  );
}

export default Dashboard;
