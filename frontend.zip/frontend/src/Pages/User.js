import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { useNavigate, useLocation } from "react-router-dom";
import axios from "axios";
import cogoToast from "cogo-toast";

export default function User() {
  const navigation = useNavigate();
  let userDtata = useLocation();
  const [userDetails, setuserDetails] = useState(userDtata.state?.data || {});

  console.log("checkDatta", userDetails);

  const { register, handleSubmit, setValue, formState: { errors }, } = useForm();
  useEffect(() => {
    setValue("FullName", userDetails?.FullName || "");
    setValue("Email", userDetails?.Email || "");
    setValue("Phone", userDetails?.Phone || "");
    setValue("Address", userDetails?.Address || "");
    setValue("PostalCode", userDetails?.PostalCode || "");
  }, [userDetails, setValue]);

  const onSubmit = (data) => {
    console.log("checkdataQQQ", data);
    const inputData = {
      ...data,
      Designation: userDetails.Designation,
      Password: userDetails.Password,
      Id: userDetails.EmployeeId != "" || userDetails.EmployeeId != null ? userDetails.EmployeeId : ""
    }
    console.log("MNMNMNMN", inputData);

    const url = "http://localhost:9696/api/authentication";

    axios
      .post(url, inputData)
      .then((res) => {
        console.log("checkresponse", res.data);
        console.log(res.data);
        if (res.data.status == true) {
          cogoToast.success("Employee Updated Successfully.");
          navigation("/userlist");
        }
      })
      .catch((error) => {
        console.error("Error submitting form:", error);
      });
  };

  return (
    <div className="maincontainer_login">
      <form onSubmit={handleSubmit(onSubmit)}>
        <div className="mb-3">
          <div style={{ color: "red" }}></div>
          <h3>Edit Employee</h3>
        </div>

        <div className="mb-3">
          <label>FullName</label>
          <div className="form-text"></div>
          <input
            type="text"
            {...register("FullName", { required: true })}
          />
          {errors.FullName && <p className="error-msg">Please enter Full Name</p>}
        </div>
        <div className="mb-3">
          <label>Email </label>
          <div className="form-text"></div>
          <input
            type="text"
            {...register("Email", { required: true })}
          />
          {errors.FullName && <p className="error-msg">Please enter Email</p>}
        </div>

        <div className="mb-3">
          <label>Phone</label>
          <div className="form-text"></div>
          <input
            type="number"
            {...register("Phone", { required: true })}
          />
          {errors.FullName && <p className="error-msg">Please enter Phone</p>}
        </div>

        <div className="mb-3">
          <label>Address</label>
          <div className="form-text"></div>
          <input
            type="text"
            {...register("Address", { required: true })}
          />
          {errors.FullName && <p className="error-msg">Please enter Address</p>}
        </div>



        <button type="submit" className="btn btn-primary">
          Submit
        </button>
        <button
          type="cancel"
          className="btn btn-primary"
          onClick={() => {
            navigation("/userlist");
          }}
        >
          Cancel
        </button>
      </form>
    </div>
  );
}
