import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { FaTrashAlt } from "react-icons/fa";
import { FaEdit } from "react-icons/fa";
import "../Components/Sidebar.css";
import axios from "axios";
import cogoToast from "cogo-toast";

function Departmentlist() {
    const navigation = useNavigate();

    const [allUsers, setAllUsers] = useState(null);
    const [deptId, setDeptId] = useState(null);



    let designation = (localStorage.getItem("designation"));

    function getDepartment() {
        axios
            .get("http://localhost:9696/api/getdepartmentdata")
            .then((res) => {
                setAllUsers(res.data.data[0]);
            })
            .catch((err) => {
                console.log(err);
            });
    }

    function Remove(id) {
        const Departmentid = {
            Id: id
        }
        const url = "http://localhost:9696/api/deleteDepartment";

        axios
            .post(url, Departmentid)
            .then((res) => {
                if (res.data.status == true) {
                    cogoToast.success("Department Removed Successfully.");
                    getDepartment();
                }
            })
            .catch((error) => {
                console.error("Error submitting form:", error);
            });
    }

    useEffect(() => {
        getDepartment();

    }, []);



    return (
        <>
            <div>
                {designation == "Manager" ?
                    <button
                        type="button"
                        class="btn btn-primary"
                        onClick={() => {
                            navigation("/adddepartment");
                        }}
                    >
                        {" "}
                        Add Department
                    </button>
                    : ""
                }

                <div className="table-head">
                    <table class="table">
                        <thead>
                            <tr>
                                <th scope="col">DepartmentId</th>
                                <th scope="col">DepartmentName</th>
                                <th scope="col">Status</th>
                                <th scope="col md-3">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            {allUsers?.map((item) => (
                                <tr>
                                    <td>{item.DepartmentId}</td>
                                    <td>{item.DepartmentName}</td>

                                    <td>
                                        <div class="form-check form-switch">
                                            <input
                                                class="form-check-input"
                                                type="checkbox"
                                                role="switch"
                                                id="flexSwitchCheckChecked"
                                                checked={item.Status == "Active"}
                                            />
                                        </div>
                                    </td>
                                    <td>
                                        {" "}
                                        <div className="action-btn">
                                            <span
                                                onClick={() => {
                                                    if (designation == "Manager") {
                                                        navigation("/adddepartment", {
                                                            state: { id: item.DepartmentId, data: item },
                                                        });
                                                    } else {
                                                        cogoToast.error("Not Allowed.")
                                                    }

                                                }}
                                            >
                                                <button type="button" class="btn btn-warning">
                                                    <FaEdit className="edit" />
                                                </button>
                                            </span>

                                            <button
                                                // onClick={""}
                                                type="button"
                                                class="btn btn-primary"

                                                data-bs-toggle={designation == "Manager" ? "modal" : ""}
                                                data-bs-target={designation == "Manager" ? "#exampleModal" : ""}
                                                onClick={() => {
                                                    if (designation == "Manager") {
                                                        setDeptId(item.DepartmentId);
                                                    } else {
                                                        cogoToast.error("Not Allowed.")
                                                    }
                                                }}
                                            >
                                                <FaTrashAlt className="delete" />
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </div>
            {/* model------------------ */}

            <div class="container">
                <div
                    class="modal fade"
                    id="exampleModal"
                    tabindex="-1"
                    aria-labelledby="exampleModalLabel"
                    aria-hidden="true"
                >
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel">
                                    Department Remove Confirmation
                                </h5>
                                <button
                                    type="button"
                                    class="btn-close"
                                    data-bs-dismiss="modal"
                                    aria-label="Close"
                                ></button>
                            </div>
                            <div class="modal-body">
                                <div class="modal-body">
                                    <p>Are you sure you want to remove this department ?</p>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button
                                    type="button"
                                    class="btn btn-secondary"
                                    data-bs-dismiss="modal"
                                >
                                    Cancel
                                </button>
                                <button type="button" class="btn btn-primary" data-bs-dismiss="modal" onClick={() => Remove(deptId)}>
                                    Ok
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </>
    );
}

export default Departmentlist;
