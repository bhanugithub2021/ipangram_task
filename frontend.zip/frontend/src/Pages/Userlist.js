import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { FaTrashAlt } from "react-icons/fa";
import { FaEdit } from "react-icons/fa";
import { MdArrowDropUp } from "react-icons/md";
import { MdArrowDropDown } from "react-icons/md";
import { MdAssignmentAdd } from "react-icons/md";



import "../Components/Sidebar.css";
import axios from "axios";
import cogoToast from "cogo-toast";
import { useForm } from "react-hook-form";

function Userlist() {
  const {
    register,
    setValue,
    formState: { errors },

  } = useForm();
  const navigation = useNavigate();

  const [allUsers, setAllUsers] = useState(null);
  const [empId, setEmpId] = useState(null);
  const [department, setDepartment] = useState(null);
  const [departmentData, setDepartmentData] = useState(null);
  const [dialog, setDialog] = useState(null);
  const [filter, setFilter] = useState("Up");
  // const [designation, setDesignation] = useState(null);

  let designation = (localStorage.getItem("designation"));

  let Currentuser = localStorage.getItem("currentuser");



  function getAllusers(filterdata) {
    if (filterdata == "NameAscending" || filterdata == "AddressAscending") {
      setFilter("Down");
    } else {
      setFilter("Up");
    }
    const inputData = {
      FilterData: filterdata,
      EmployeeId: designation == "Employee" ? Currentuser : ""
    }

    const url = "http://localhost:9696/api/getEmployeeData";

    axios
      .post(url, inputData)
      .then((res) => {
        setAllUsers(res.data.data[0]);
      })
      .catch((err) => {
        console.log(err);
      });
  }

  function Remove(id) {
    const Empid = {
      Id: id
    }
    const url = "http://localhost:9696/api/deleteEmployee";

    axios
      .post(url, Empid)
      .then((res) => {
        if (res.data.status == true) {
          cogoToast.success("Employee Removed Successfully.");
          getAllusers("");
        }
      })
      .catch((error) => {
        console.error("Error submitting form:", error);
      });
  }


  function Assigndepartment(id) {
    const Empid = {
      Id: id,
      Department: department
    }
    const url = "http://localhost:9696/api/assignDepartment";
    axios
      .post(url, Empid)
      .then((res) => {
        if (res.data.status == true) {
          cogoToast.success("Department Assigned Successfully.");
          getAllusers("");
          setDepartment(null);
        }
      })
      .catch((error) => {
        console.error("Error submitting form:", error);
      });
  }

  useEffect(() => {
    getAllusers("");
    getDepartment();

  }, []);

  function getDepartment() {
    axios
      .get("http://localhost:9696/api/getdepartmentdata")
      .then((res) => {
        setDepartmentData(res.data.data[0]);
      })
      .catch((err) => {
        console.log(err);
      });
  }

  let dummyAsendng = "Active"


  return (
    <>
      <div>

        <div className="table-head">
          <table class="table">
            <thead>
              <tr>
                <th scope="col" className="nor-arrow">EmployeeId</th>
                <th scope="col" className="arrow-icon"><p>FullName</p> {filter === "Up" ?
                  <span onClick={() => getAllusers("NameAscending")}><MdArrowDropUp /> </span> :
                  <span onClick={() => getAllusers("NameDscending")}><MdArrowDropDown /></span>}
                </th>
                <th scope="col">Email</th>
                <th scope="col">Phone</th>
                <th scope="col" className="arrow-icon"><p>Address</p> {filter === "Up" ?
                  <span onClick={() => getAllusers("AddressAscending")}><MdArrowDropUp /> </span> :
                  <span onClick={() => getAllusers("AddressDscending")}><MdArrowDropDown /></span>}
                </th>
                <th scope="col">Status</th>
                <th scope="col">Designation</th>
                <th scope="col">Department</th>
                <th scope="col md-3">Action</th>
              </tr>
            </thead>
            <tbody>
              {allUsers?.map((item) => (
                <tr>
                  <td>{item.EmployeeId}</td>
                  <td>{item.FullName}</td>
                  <td>{item.Email}</td>
                  <td>{item.Phone}</td>
                  <td>{item.Address}</td>



                  <td>
                    <div class="form-check form-switch">
                      <input
                        class="form-check-input"
                        type="checkbox"
                        role="switch"
                        id="flexSwitchCheckChecked"
                        checked={item.Status == "Active"}
                      />
                    </div>
                  </td>
                  <td>{item.Designation ? item.Designation : ""}</td>
                  <td>{item.Department ? item.Department : ""}</td>
                  <td>
                    {" "}
                    <div className="action-btn">
                      <span
                        onClick={() => {
                          if (designation == "Manager") {
                            navigation("/user/edit", {
                              state: { id: item.EmployeeId, data: item },
                            });
                          } else {
                            cogoToast.error("Not Allowed.")
                          }
                        }}

                      >
                        <button type="button" class="btn btn-warning">
                          <FaEdit className="edit" />
                        </button>
                      </span>
                      {item.Designation == "Employee" ? <button
                        // onClick={""}
                        type="button"
                        class="btn btn-primary"
                        data-bs-toggle={designation == "Manager" ? "modal" : ""}
                        data-bs-target={designation == "Manager" ? "#exampleModal" : ""}
                        onClick={() => {
                          if (designation == "Manager") {
                            setEmpId(item.EmployeeId);
                            setDialog("AssignDepartment");
                          } else {
                            cogoToast.error("Not Allowed.")
                          }
                        }}
                      >
                        <MdAssignmentAdd className="edit" style={{ color: "rebeccapurple" }} />
                      </button> : ""}


                      <button
                        // onClick={""}
                        type="button"
                        class="btn btn-primary"
                        data-bs-toggle={designation == "Manager" ? "modal" : ""}
                        data-bs-target={designation == "Manager" ? "#exampleModal" : ""}
                        onClick={() => {
                          if (designation == "Manager") {
                            setEmpId(item.EmployeeId);
                            setDialog("RemoveEmployee");
                          } else {
                            cogoToast.error("Not Allowed.")
                          }
                        }}
                      >
                        <FaTrashAlt className="delete" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* model------------------ */}

      <div class="container">
        <div
          class="modal fade"
          id="exampleModal"
          tabindex="-1"
          aria-labelledby="exampleModalLabel"
          aria-hidden="true"
        >
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">
                  {dialog == "RemoveEmployee" ? "Employee Remove Confirmation" : "Assign Department"}
                </h5>
                <button
                  type="button"
                  class="btn-close"
                  data-bs-dismiss="modal"
                  aria-label="Close"
                ></button>
              </div>
              <div class="modal-body">
                <div class="modal-body">
                  {dialog == "RemoveEmployee" ?
                    <div className="delete-text">
                      <p>Are you sure you want to remove this  employee data ?</p>
                    </div>
                    :
                    <div className="mb-3">
                      <label>Department</label>
                      <div className="form-text"></div>

                      <select className="select_dr"
                        {...register("Department", { required: "Please Select Department" })}
                        onChange={(e) =>
                          setDepartment(e.target.value)

                        }
                      >
                        {departmentData?.map((item) => {
                          return (
                            <option
                              key={item.DepartmentName}
                              value={item.DepartmentId}
                            >
                              {item.DepartmentName}
                            </option>
                          )
                        })}

                      </select>

                      {errors.Department && (
                        <p className="error-msg">Please Enter Department</p>
                      )}
                    </div>
                  }
                </div>
              </div>
              <div class="modal-footer">
                <button
                  type="button"
                  class="btn btn-secondary"
                  data-bs-dismiss="modal"
                >
                  Cancel
                </button>
                {
                  dialog == "RemoveEmployee" ?
                    <button type="button" class="btn btn-primary" data-bs-dismiss="modal" onClick={() => Remove(empId)}>
                      Ok
                    </button> :
                    <button type="button" class="btn btn-primary" data-bs-dismiss="modal" onClick={() => Assigndepartment(empId)}>
                      Ok
                    </button>
                }



              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

export default Userlist;
